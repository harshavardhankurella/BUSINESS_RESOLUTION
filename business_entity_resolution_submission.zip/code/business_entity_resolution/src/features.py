"""
features.py
Turns a (Source-1 record, candidate record) pair into a fixed-length
numeric feature vector for the classifier. Pure stdlib + numpy, no
external string-distance library required (difflib.SequenceMatcher
stands in for Levenshtein ratio).
"""
from difflib import SequenceMatcher

import numpy as np

from normalize import normalize_name, normalize_address, tokens

FEATURE_NAMES = [
    "name_char_sim",
    "name_token_jaccard",
    "name_token_overlap",
    "name_len_diff",
    "addr_char_sim",
    "addr_token_jaccard",
    "addr_first_token_match",
    "country_match",
    "name_prefix_match",
]


def _char_sim(a, b):
    if not a and not b:
        return 1.0
    return SequenceMatcher(None, a, b).ratio()


def _jaccard(set_a, set_b):
    if not set_a and not set_b:
        return 1.0
    union = set_a | set_b
    if not union:
        return 1.0
    return len(set_a & set_b) / len(union)


def pair_features(s1_row, other_row):
    n1, n2 = normalize_name(s1_row["business_name"]), normalize_name(other_row["business_name"])
    a1, a2 = normalize_address(s1_row["business_address"]), normalize_address(other_row["business_address"])
    t1, t2 = tokens(n1), tokens(n2)
    at1, at2 = tokens(a1), tokens(a2)

    c1 = str(s1_row.get("country", "")).strip().lower()
    c2 = str(other_row.get("country", "")).strip().lower()

    feats = {
        "name_char_sim": _char_sim(n1, n2),
        "name_token_jaccard": _jaccard(t1, t2),
        "name_token_overlap": len(t1 & t2),
        "name_len_diff": abs(len(n1) - len(n2)) / max(len(n1), len(n2), 1),
        "addr_char_sim": _char_sim(a1, a2),
        "addr_token_jaccard": _jaccard(at1, at2),
        "addr_first_token_match": float(a1.split()[0] == a2.split()[0]) if a1 and a2 else 0.0,
        "country_match": float(c1 == c2),
        "name_prefix_match": float(n1[:4] == n2[:4]) if n1 and n2 else 0.0,
    }
    return [feats[k] for k in FEATURE_NAMES]


def build_feature_matrix(s1_df, other_df_by_id, pairs):
    """
    pairs: list of (s1_entity_id, other_entity_id)
    s1_df: DataFrame indexed by entity_id (or with entity_id column)
    other_df_by_id: dict entity_id -> row (dict-like) for S2+S3 combined
    Returns: X (np.ndarray), ordered list of pairs actually used
    """
    s1_by_id = s1_df.set_index("entity_id").to_dict(orient="index")
    X, used_pairs = [], []
    for s1_id, other_id in pairs:
        if s1_id not in s1_by_id or other_id not in other_df_by_id:
            continue
        X.append(pair_features(s1_by_id[s1_id], other_df_by_id[other_id]))
        used_pairs.append((s1_id, other_id))
    return np.array(X, dtype=float), used_pairs
