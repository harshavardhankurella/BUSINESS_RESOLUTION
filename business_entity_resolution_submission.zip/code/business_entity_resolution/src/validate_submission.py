"""
validate_submission.py (stdlib only)
Local re-implementation of the checks described in the problem statement,
so you can catch formatting issues before spending a leaderboard
submission. Does NOT compute your score -- only checks file validity.

Run:
    python3 validate_submission.py \
        --matching ../../output/matching_results.tsv \
        --candidate ../../output/candidate_pairs.tsv \
        --test-dir ../../dataset/test
"""
import argparse
import csv
import sys


def read_ids(path):
    ids = []
    with open(path, encoding="utf-8") as f:
        reader = csv.reader(f, delimiter="\t")
        header = next(reader)
        for row in reader:
            if not row:
                continue
            ids.append(row[0])
    return set(ids)


def read_id_list_file(path, id_col, list_col):
    """Returns dict s1_id -> list of ids (possibly empty), plus raw row order."""
    rows = {}
    order = []
    with open(path, encoding="utf-8") as f:
        reader = csv.reader(f, delimiter="\t")
        header = next(reader)
        if header[:2] != [id_col, list_col]:
            raise ValueError(f"{path}: expected header {id_col}\\t{list_col}, got {header}")
        for row in reader:
            if not row:
                continue
            s1_id = row[0]
            id_list_raw = row[1] if len(row) > 1 else ""
            ids = id_list_raw.split(",") if id_list_raw.strip() else []
            rows[s1_id] = ids
            order.append(s1_id)
    return rows, order


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--matching", required=True)
    ap.add_argument("--candidate", required=True)
    ap.add_argument("--test-dir", required=True)
    args = ap.parse_args()

    issues = []

    s1_ids = read_ids(f"{args.test_dir}/test_source1.tsv")
    s2_ids = read_ids(f"{args.test_dir}/test_source2.tsv")
    s3_ids = read_ids(f"{args.test_dir}/test_source3.tsv")
    valid_other_ids = s2_ids | s3_ids

    match_rows, match_order = read_id_list_file(args.matching, "source1_entity_id", "matched_entity_ids")
    cand_rows, cand_order = read_id_list_file(args.candidate, "source1_entity_id", "candidate_entity_ids")

    # 1. Every S1 test entity must appear exactly once.
    if len(match_order) != len(set(match_order)):
        issues.append("matching_results.tsv: duplicate source1_entity_id rows found.")
    if len(cand_order) != len(set(cand_order)):
        issues.append("candidate_pairs.tsv: duplicate source1_entity_id rows found.")

    missing_in_match = s1_ids - set(match_rows.keys())
    extra_in_match = set(match_rows.keys()) - s1_ids
    if missing_in_match:
        issues.append(f"matching_results.tsv: missing {len(missing_in_match)} S1 entities "
                       f"(e.g. {sorted(missing_in_match)[:5]}).")
    if extra_in_match:
        issues.append(f"matching_results.tsv: {len(extra_in_match)} rows reference S1 ids "
                       f"not in test set (e.g. {sorted(extra_in_match)[:5]}).")

    missing_in_cand = s1_ids - set(cand_rows.keys())
    if missing_in_cand:
        issues.append(f"candidate_pairs.tsv: missing {len(missing_in_cand)} S1 entities "
                       f"(e.g. {sorted(missing_in_cand)[:5]}).")

    # 2/4. IDs must be valid S2/S3 test ids, no self-matches, no dup within a list.
    for s1_id, ids in match_rows.items():
        if len(ids) != len(set(ids)):
            issues.append(f"matching_results.tsv: duplicate ids within row {s1_id}.")
        for i in ids:
            if i.startswith("S1-"):
                issues.append(f"matching_results.tsv: self-match to Source 1 id {i} in row {s1_id}.")
            elif i not in valid_other_ids:
                issues.append(f"matching_results.tsv: id {i} in row {s1_id} not found in test S2/S3.")

    for s1_id, ids in cand_rows.items():
        if len(ids) != len(set(ids)):
            issues.append(f"candidate_pairs.tsv: duplicate ids within row {s1_id}.")
        for i in ids:
            if i not in valid_other_ids:
                issues.append(f"candidate_pairs.tsv: id {i} in row {s1_id} not found in test S2/S3.")

    # Consistency: every matched id should also be a candidate for that S1 entity.
    warn_count = 0
    for s1_id, ids in match_rows.items():
        cand_set = set(cand_rows.get(s1_id, []))
        for i in ids:
            if i not in cand_set:
                warn_count += 1
    if warn_count:
        issues.append(f"WARNING: {warn_count} matched id(s) never appeared as a candidate "
                       f"for their S1 entity -- possible pipeline bug.")

    if issues:
        print("Issues found:")
        for i, msg in enumerate(issues, 1):
            print(f"  {i}. {msg}")
        sys.exit(1)
    else:
        print("PASS")
        sys.exit(0)


if __name__ == "__main__":
    main()
