"""
predict.py
Runs the full pipeline on the test set and writes the two required output
files: output/matching_results.tsv and output/candidate_pairs.tsv.

Run:
    python3 predict.py --data-dir ../../dataset/test --model model.joblib --out-dir ../../output
"""
import argparse
import os

import joblib
import pandas as pd

from blocking import generate_candidates
from features import build_feature_matrix


def write_id_list_tsv(path, id_col, list_col, rows_dict):
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"{id_col}\t{list_col}\n")
        for s1_id in sorted(rows_dict.keys()):
            ids = rows_dict[s1_id]
            f.write(f"{s1_id}\t{','.join(sorted(ids))}\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default="../../dataset/test")
    ap.add_argument("--model", default="model.joblib")
    ap.add_argument("--out-dir", default="../../output")
    args = ap.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)

    s1 = pd.read_csv(f"{args.data_dir}/test_source1.tsv", sep="\t", dtype=str).fillna("")
    s2 = pd.read_csv(f"{args.data_dir}/test_source2.tsv", sep="\t", dtype=str).fillna("")
    s3 = pd.read_csv(f"{args.data_dir}/test_source3.tsv", sep="\t", dtype=str).fillna("")

    bundle = joblib.load(args.model)
    clf, threshold = bundle["model"], bundle["threshold"]

    # ---- Candidate generation (this IS candidate_pairs.tsv) ----
    candidates = generate_candidates(s1, s2, s3)

    all_s1_ids = s1["entity_id"].tolist()
    candidate_rows = {eid: set(candidates.get(eid, [])) for eid in all_s1_ids}
    write_id_list_tsv(f"{args.out_dir}/candidate_pairs.tsv",
                       "source1_entity_id", "candidate_entity_ids", candidate_rows)

    # ---- Score every candidate pair, keep those >= threshold ----
    other_by_id = {}
    for _, r in pd.concat([s2, s3]).iterrows():
        other_by_id[r["entity_id"]] = r.to_dict()

    pairs = [(s1_id, cid) for s1_id, cids in candidates.items() for cid in cids]
    match_rows = {eid: set() for eid in all_s1_ids}

    if pairs:
        X, used_pairs = build_feature_matrix(s1, other_by_id, pairs)
        if len(X):
            probs = clf.predict_proba(X)[:, 1]
            for (s1_id, cid), p in zip(used_pairs, probs):
                if p >= threshold:
                    match_rows[s1_id].add(cid)

    write_id_list_tsv(f"{args.out_dir}/matching_results.tsv",
                       "source1_entity_id", "matched_entity_ids", match_rows)

    n_matched = sum(1 for v in match_rows.values() if v)
    print(f"Wrote {args.out_dir}/matching_results.tsv "
          f"({n_matched}/{len(all_s1_ids)} S1 entities have >=1 match)")
    print(f"Wrote {args.out_dir}/candidate_pairs.tsv")


if __name__ == "__main__":
    main()
