"""
generate_synthetic_data.py

The real Amazon ML Challenge dataset (train_source1.tsv, train_source2.tsv,
train_source3.tsv, train_ground_truth.tsv, test_source*.tsv) was not
available in this environment. This script fabricates a small but
structurally identical dataset so the rest of the pipeline
(blocking -> features -> training -> prediction -> validation) can be
built, run and unit-tested end to end.

*** Replace this synthetic data with the real challenge files as soon as
you have them: drop them into dataset/train/ and dataset/test/ with the
exact same filenames, and everything downstream keeps working unchanged. ***

Usage:
    python3 generate_synthetic_data.py --outdir ../../dataset --n-entities 400
"""
import argparse
import csv
import random
import string

random.seed(42)

US_CITIES = ["Austin TX", "Seattle WA", "Denver CO", "Miami FL", "Chicago IL"]
IN_CITIES = ["Pune MH", "Chennai TN", "Jaipur RJ", "Indore MP", "Nagpur MH"]
FR_CITIES = ["Lyon", "Nantes", "Toulouse", "Nice", "Marseille"]

US_STREETS = ["Main St", "Oak Ave", "Park Rd", "5th Avenue", "Lincoln Blvd"]
IN_STREETS = ["MG Road", "Station Road", "Gandhi Nagar", "Ring Road", "Civil Lines"]
FR_STREETS = ["Rue de la Paix", "Avenue Victor Hugo", "Rue Nationale", "Boulevard Saint-Michel"]

NAME_WORDS = ["Sunrise", "Global", "Prime", "Metro", "Royal", "Bluepeak", "Nova",
              "Greenfield", "United", "Apex", "Silver", "Golden", "Orbit", "Vista"]
NAME_TYPES = ["Traders", "Enterprises", "Solutions", "Foods", "Textiles", "Electronics",
              "Logistics", "Retail", "Pharma", "Motors", "Bakery", "Consulting"]
SUFFIX_US = ["LLC", "Inc", "Corp", "Co"]
SUFFIX_IN = ["Pvt Ltd", "Private Limited", "Ltd", "and Sons"]
SUFFIX_FR = ["SARL", "SAS", "SA"]


def rand_name(country):
    base = f"{random.choice(NAME_WORDS)} {random.choice(NAME_TYPES)}"
    if country == "US":
        return f"{base} {random.choice(SUFFIX_US)}"
    if country == "India":
        return f"{base} {random.choice(SUFFIX_IN)}"
    return f"{base} {random.choice(SUFFIX_FR)}"


def rand_address(country):
    num = random.randint(1, 999)
    if country == "US":
        return f"{num} {random.choice(US_STREETS)}, {random.choice(US_CITIES)}"
    if country == "India":
        return f"{num}, {random.choice(IN_STREETS)}, {random.choice(IN_CITIES)}"
    return f"{num} {random.choice(FR_STREETS)}, {random.choice(FR_CITIES)}"


def typo(s, p=0.15):
    """Randomly perturb a string to simulate OCR/typing noise."""
    if random.random() > p or len(s) < 4:
        return s
    i = random.randint(0, len(s) - 2)
    chars = list(s)
    op = random.choice(["swap", "drop", "dup"])
    if op == "swap":
        chars[i], chars[i + 1] = chars[i + 1], chars[i]
    elif op == "drop":
        del chars[i]
    else:
        chars.insert(i, chars[i])
    return "".join(chars)


def abbreviate_name(name):
    repl = {
        "Private Limited": "Pvt Ltd", "Pvt Ltd": "Pvt. Ltd.", "Corp": "Corporation",
        "Inc": "Incorporated", "and": "&", "Ltd": "Limited",
    }
    out = name
    for a, b in repl.items():
        if a in out and random.random() < 0.5:
            out = out.replace(a, b)
            break
    return typo(out)


def abbreviate_address(addr):
    repl = {"Road": "Rd", "Street": "St", "Avenue": "Ave", "Boulevard": "Blvd"}
    out = addr
    for a, b in repl.items():
        out = out.replace(a, b)
    if random.random() < 0.2:
        # drop the trailing city/PIN component to simulate partial address
        out = out.split(",")[0]
    return typo(out, p=0.1)


def build_source1(n, countries):
    rows = []
    for i in range(1, n + 1):
        c = random.choice(countries)
        eid = f"S1-{i:05d}"
        rows.append({
            "entity_id": eid,
            "business_name": rand_name(c),
            "business_address": rand_address(c),
            "country": c,
        })
    return rows


def build_matches(s1_rows, prefix, match_rate, max_matches, id_counter):
    """For each S1 row, maybe create 0..max_matches noisy duplicates in
    another source. Returns (rows, {s1_id: [matched_ids]})."""
    rows, gt = [], {}
    for r in s1_rows:
        gt[r["entity_id"]] = []
        n_matches = 0
        if random.random() < match_rate:
            n_matches = random.randint(1, max_matches)
        for _ in range(n_matches):
            eid = f"{prefix}-{id_counter[0]:05d}"
            id_counter[0] += 1
            rows.append({
                "entity_id": eid,
                "business_name": abbreviate_name(r["business_name"]),
                "business_address": abbreviate_address(r["business_address"]),
                "country": r["country"],
            })
            gt[r["entity_id"]].append(eid)
    return rows, gt


def build_noise_records(prefix, n, countries, id_counter):
    """Unrelated records in S2/S3 with no S1 match (true negatives)."""
    rows = []
    for _ in range(n):
        c = random.choice(countries)
        eid = f"{prefix}-{id_counter[0]:05d}"
        id_counter[0] += 1
        rows.append({
            "entity_id": eid,
            "business_name": rand_name(c),
            "business_address": rand_address(c),
            "country": c,
        })
    return rows


def write_tsv(path, rows, fieldnames):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, delimiter="\t")
        w.writeheader()
        for r in rows:
            w.writerow(r)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", default="../../dataset")
    ap.add_argument("--n-entities", type=int, default=400)
    args = ap.parse_args()

    fieldnames = ["entity_id", "business_name", "business_address", "country"]

    # ---------- TRAIN (US, India only, per problem statement) ----------
    train_countries = ["US", "India"]
    s1_train = build_source1(args.n_entities, train_countries)
    id2 = [1]
    id3 = [1]
    s2_matches, gt2 = build_matches(s1_train, "S2", match_rate=0.6, max_matches=2, id_counter=id2)
    s3_matches, gt3 = build_matches(s1_train, "S3", match_rate=0.5, max_matches=2, id_counter=id3)
    s2_noise = build_noise_records("S2", int(args.n_entities * 0.3), train_countries, id2)
    s3_noise = build_noise_records("S3", int(args.n_entities * 0.3), train_countries, id3)
    s2_train = s2_matches + s2_noise
    s3_train = s3_matches + s3_noise
    random.shuffle(s2_train)
    random.shuffle(s3_train)

    gt_rows = []
    for r in s1_train:
        eid = r["entity_id"]
        matched = gt2.get(eid, []) + gt3.get(eid, [])
        gt_rows.append({"source1_entity_id": eid, "matched_entity_ids": ",".join(matched)})

    write_tsv(f"{args.outdir}/train/train_source1.tsv", s1_train, fieldnames)
    write_tsv(f"{args.outdir}/train/train_source2.tsv", s2_train, fieldnames)
    write_tsv(f"{args.outdir}/train/train_source3.tsv", s3_train, fieldnames)
    write_tsv(f"{args.outdir}/train/train_ground_truth.tsv", gt_rows,
              ["source1_entity_id", "matched_entity_ids"])

    # ---------- TEST (US, India, + unseen France) ----------
    test_countries = ["US", "India", "France"]
    n_test = max(50, args.n_entities // 4)
    s1_test = build_source1(n_test, test_countries)
    id2t = [1]
    id3t = [1]
    s2t_matches, _ = build_matches(s1_test, "S2", match_rate=0.6, max_matches=2, id_counter=id2t)
    s3t_matches, _ = build_matches(s1_test, "S3", match_rate=0.5, max_matches=2, id_counter=id3t)
    s2t_noise = build_noise_records("S2", int(n_test * 0.3), test_countries, id2t)
    s3t_noise = build_noise_records("S3", int(n_test * 0.3), test_countries, id3t)
    s2_test = s2t_matches + s2t_noise
    s3_test = s3t_matches + s3t_noise
    random.shuffle(s2_test)
    random.shuffle(s3_test)

    write_tsv(f"{args.outdir}/test/test_source1.tsv", s1_test, fieldnames)
    write_tsv(f"{args.outdir}/test/test_source2.tsv", s2_test, fieldnames)
    write_tsv(f"{args.outdir}/test/test_source3.tsv", s3_test, fieldnames)

    print(f"Synthetic data written under {args.outdir}/")
    print(f"  train: S1={len(s1_train)} S2={len(s2_train)} S3={len(s3_train)}")
    print(f"  test:  S1={len(s1_test)} S2={len(s2_test)} S3={len(s3_test)}")


if __name__ == "__main__":
    main()
