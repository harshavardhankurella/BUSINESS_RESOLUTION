"""
normalize.py
Text-normalization helpers shared by blocking, feature engineering and
training. Everything here is deterministic, dependency-free (stdlib only)
and works the same way on train and test data / any country label,
including unseen ones like France.
"""
import re

# Common legal-suffix / abbreviation variants seen in business names.
# Mapping "noisy form" -> "canonical form". Order matters (longer first).
_SUFFIX_MAP = {
    "private limited": "pvt ltd",
    "pvt. ltd.": "pvt ltd",
    "pvt.ltd": "pvt ltd",
    "private ltd": "pvt ltd",
    "corporation": "corp",
    "incorporated": "inc",
    "limited liability company": "llc",
    "limited": "ltd",
    "company": "co",
    "& ": " and ",
    " & ": " and ",
}

_ADDR_ABBR_MAP = {
    "road": "rd",
    "street": "st",
    "avenue": "ave",
    "boulevard": "blvd",
    "apartment": "apt",
    "floor": "fl",
    "building": "bldg",
    "near": "near",
}

_PUNCT_RE = re.compile(r"[^\w\s]")
_MULTI_SPACE_RE = re.compile(r"\s+")


def _apply_map(text: str, mapping: dict) -> str:
    for k, v in mapping.items():
        text = text.replace(k, v)
    return text


def normalize_name(name: str) -> str:
    """Lowercase, expand/collapse legal suffixes, strip punctuation."""
    if not isinstance(name, str):
        return ""
    t = name.lower().strip()
    t = _apply_map(t, _SUFFIX_MAP)
    t = _PUNCT_RE.sub(" ", t)
    t = _MULTI_SPACE_RE.sub(" ", t).strip()
    return t


def normalize_address(addr: str) -> str:
    """Lowercase, expand common street abbreviations, strip punctuation."""
    if not isinstance(addr, str):
        return ""
    t = addr.lower().strip()
    t = _PUNCT_RE.sub(" ", t)
    tokens = t.split()
    tokens = [_ADDR_ABBR_MAP.get(tok, tok) for tok in tokens]
    t = " ".join(tokens)
    t = _MULTI_SPACE_RE.sub(" ", t).strip()
    return t


def tokens(text: str) -> set:
    return set(text.split()) if text else set()


def blocking_key(norm_name: str, country: str) -> str:
    """
    Coarse key used for the first blocking pass: first alphabetic token of
    the normalized name (falls back to first 4 chars) + country label.
    Works for any country string, including ones never seen in training
    (e.g. France in the test set) since it's just a string bucket.
    """
    country_key = (country or "unk").strip().lower()
    toks = norm_name.split()
    if toks:
        name_key = toks[0][:4]
    else:
        name_key = norm_name[:4]
    return f"{country_key}::{name_key}"
