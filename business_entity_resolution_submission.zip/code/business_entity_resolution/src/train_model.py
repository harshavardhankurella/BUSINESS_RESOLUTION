"""
train_model.py
End-to-end training:
  1. Load train_source1/2/3 + train_ground_truth.
  2. Hold out a validation split of Source-1 entities (grouped split, so a
     given S1 entity's positives/negatives stay together).
  3. Run blocking on the train split to build candidate pairs.
  4. Label pairs (positive = in ground truth, negative = candidate but not
     a true match -> hard negatives from the blocker itself).
  5. Train a small RandomForest classifier (scikit-learn, BSD-3 license,
     ~tens of KB of parameters -- trivially within the 8B-parameter /
     MIT-Apache license constraint).
  6. Sweep the decision threshold on the validation split to maximise
     macro-averaged F_0.5 (matches the leaderboard metric), then persist
     model + threshold.

Run:
    python3 train_model.py --data-dir ../../dataset/train --model-out ../../code/business_entity_resolution/model.joblib
"""
import argparse
import json

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GroupShuffleSplit

from blocking import generate_candidates
from features import build_feature_matrix, FEATURE_NAMES


def f_beta_macro(y_true_groups, y_pred_groups, beta=0.5):
    """
    y_true_groups / y_pred_groups: dict s1_id -> set(matched_ids)
    Per-entity F_beta, averaged across every S1 entity in y_true_groups
    (singletons included, matching the challenge's macro-average rule).
    """
    scores = []
    for s1_id, true_set in y_true_groups.items():
        pred_set = y_pred_groups.get(s1_id, set())
        if not true_set and not pred_set:
            scores.append(1.0)
            continue
        if not pred_set:
            scores.append(0.0)
            continue
        tp = len(true_set & pred_set)
        precision = tp / len(pred_set) if pred_set else 0.0
        recall = tp / len(true_set) if true_set else 0.0
        if precision == 0 and recall == 0:
            scores.append(0.0)
            continue
        f = (1 + beta**2) * precision * recall / (beta**2 * precision + recall + 1e-12)
        scores.append(f)
    return float(np.mean(scores)) if scores else 0.0


def load_data(data_dir):
    s1 = pd.read_csv(f"{data_dir}/train_source1.tsv", sep="\t", dtype=str).fillna("")
    s2 = pd.read_csv(f"{data_dir}/train_source2.tsv", sep="\t", dtype=str).fillna("")
    s3 = pd.read_csv(f"{data_dir}/train_source3.tsv", sep="\t", dtype=str).fillna("")
    gt = pd.read_csv(f"{data_dir}/train_ground_truth.tsv", sep="\t", dtype=str).fillna("")
    gt_map = {}
    for _, row in gt.iterrows():
        matched = row["matched_entity_ids"].strip()
        gt_map[row["source1_entity_id"]] = set(matched.split(",")) if matched else set()
    return s1, s2, s3, gt_map


def build_labeled_pairs(s1_df, s2_df, s3_df, gt_map, candidates):
    other_by_id = {}
    for _, r in pd.concat([s2_df, s3_df]).iterrows():
        other_by_id[r["entity_id"]] = r.to_dict()

    pairs, labels = [], []
    for s1_id, cand_ids in candidates.items():
        true_matches = gt_map.get(s1_id, set())
        for cid in cand_ids:
            pairs.append((s1_id, cid))
            labels.append(1 if cid in true_matches else 0)
    X, used_pairs = build_feature_matrix(s1_df, other_by_id, pairs)
    used_pair_set = set(used_pairs)
    y = np.array([lab for p, lab in zip(pairs, labels) if p in used_pair_set])
    return X, y, used_pairs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data-dir", default="../../dataset/train")
    ap.add_argument("--model-out", default="model.joblib")
    ap.add_argument("--val-frac", type=float, default=0.25)
    args = ap.parse_args()

    s1, s2, s3, gt_map = load_data(args.data_dir)

    # Grouped split: whole S1 entities go to either train or validation.
    splitter = GroupShuffleSplit(n_splits=1, test_size=args.val_frac, random_state=42)
    idx = np.arange(len(s1))
    train_idx, val_idx = next(splitter.split(idx, groups=idx))
    s1_train, s1_val = s1.iloc[train_idx].reset_index(drop=True), s1.iloc[val_idx].reset_index(drop=True)

    print(f"Train S1={len(s1_train)}  Val S1={len(s1_val)}")

    # ---- Candidate generation (blocking) on each split ----
    cand_train = generate_candidates(s1_train, s2, s3)
    cand_val = generate_candidates(s1_val, s2, s3)

    # Recall ceiling check: how many true matches survive blocking.
    def recall_ceiling(s1_split, cand):
        tot, found = 0, 0
        for _, r in s1_split.iterrows():
            trues = gt_map.get(r["entity_id"], set())
            tot += len(trues)
            found += len(trues & set(cand.get(r["entity_id"], [])))
        return found / tot if tot else 1.0

    print(f"Blocking recall ceiling (train): {recall_ceiling(s1_train, cand_train):.3f}")
    print(f"Blocking recall ceiling (val):   {recall_ceiling(s1_val, cand_val):.3f}")

    # ---- Build labeled feature matrix on TRAIN split ----
    X_train, y_train, _ = build_labeled_pairs(s1_train, s2, s3, gt_map, cand_train)
    print(f"Train pairs: {len(y_train)}  positives: {y_train.sum()}")

    clf = RandomForestClassifier(
        n_estimators=200, max_depth=8, min_samples_leaf=3,
        class_weight="balanced_subsample", random_state=42, n_jobs=-1,
    )
    clf.fit(X_train, y_train)

    # ---- Threshold sweep on VALIDATION split, optimizing macro F0.5 ----
    other_val_by_id = {}
    for _, r in pd.concat([s2, s3]).iterrows():
        other_val_by_id[r["entity_id"]] = r.to_dict()

    val_pairs = [(s1_id, cid) for s1_id, cids in cand_val.items() for cid in cids]
    X_val, used_val_pairs = build_feature_matrix(s1_val, other_val_by_id, val_pairs)
    val_probs = clf.predict_proba(X_val)[:, 1] if len(X_val) else np.array([])

    y_true_groups = {r["entity_id"]: gt_map.get(r["entity_id"], set()) for _, r in s1_val.iterrows()}

    best_t, best_f = 0.5, -1.0
    for t in np.arange(0.30, 0.96, 0.02):
        pred_groups = {eid: set() for eid in y_true_groups}
        for (s1_id, cid), p in zip(used_val_pairs, val_probs):
            if p >= t:
                pred_groups[s1_id].add(cid)
        f = f_beta_macro(y_true_groups, pred_groups, beta=0.5)
        if f > best_f:
            best_f, best_t = f, t
    print(f"Best threshold: {best_t:.2f}  Validation macro F0.5: {best_f:.4f}")

    joblib.dump({"model": clf, "threshold": float(best_t), "feature_names": FEATURE_NAMES}, args.model_out)
    with open(args.model_out + ".metrics.json", "w") as f:
        json.dump({"val_f0.5": best_f, "threshold": best_t,
                    "recall_ceiling_train": recall_ceiling(s1_train, cand_train),
                    "recall_ceiling_val": recall_ceiling(s1_val, cand_val)}, f, indent=2)
    print(f"Saved model to {args.model_out}")


if __name__ == "__main__":
    main()
