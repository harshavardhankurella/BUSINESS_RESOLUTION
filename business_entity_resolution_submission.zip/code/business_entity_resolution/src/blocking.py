"""
blocking.py
Candidate-generation stage. Determines the recall ceiling of the whole
pipeline, so it deliberately over-generates (favours recall) and lets the
downstream classifier + threshold handle precision.

Strategy (works for any country label, including ones unseen at train
time, e.g. France in the test set):
  1. Coarse exact-key blocking: normalized-name-first-token + country.
  2. Character n-gram TF-IDF + cosine nearest-neighbours within each
     country group, to catch typos / reordered / abbreviated names that
     the exact key misses.
  3. Union of both candidate sets, deduplicated.
"""
from collections import defaultdict

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neighbors import NearestNeighbors

from normalize import normalize_name, normalize_address, blocking_key

TOP_K = 8  # neighbours pulled per S1 entity per source, per country group


def _prep(df):
    df = df.copy()
    df["norm_name"] = df["business_name"].map(normalize_name)
    df["norm_addr"] = df["business_address"].map(normalize_address)
    df["country_norm"] = df["country"].fillna("unk").str.strip().str.lower()
    return df


def _exact_key_candidates(s1_df, other_df):
    """entity_id -> set(candidate entity_id) via shared blocking key."""
    key_to_others = defaultdict(list)
    for _, row in other_df.iterrows():
        k = blocking_key(row["norm_name"], row["country_norm"])
        key_to_others[k].append(row["entity_id"])

    cands = defaultdict(set)
    for _, row in s1_df.iterrows():
        k = blocking_key(row["norm_name"], row["country_norm"])
        for oid in key_to_others.get(k, []):
            cands[row["entity_id"]].add(oid)
    return cands


def _tfidf_knn_candidates(s1_df, other_df, top_k=TOP_K):
    """entity_id -> set(candidate entity_id) via per-country TF-IDF kNN
    over normalized name+address text."""
    cands = defaultdict(set)
    if other_df.empty or s1_df.empty:
        return cands

    for country in s1_df["country_norm"].unique():
        s1_grp = s1_df[s1_df["country_norm"] == country]
        other_grp = other_df[other_df["country_norm"] == country]
        if other_grp.empty or s1_grp.empty:
            continue

        s1_text = (s1_grp["norm_name"] + " " + s1_grp["norm_addr"]).tolist()
        other_text = (other_grp["norm_name"] + " " + other_grp["norm_addr"]).tolist()

        vec = TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 4), min_df=1)
        try:
            all_matrix = vec.fit_transform(s1_text + other_text)
        except ValueError:
            continue
        s1_matrix = all_matrix[: len(s1_text)]
        other_matrix = all_matrix[len(s1_text):]

        k = min(top_k, other_matrix.shape[0])
        if k == 0:
            continue
        nn = NearestNeighbors(n_neighbors=k, metric="cosine")
        nn.fit(other_matrix)
        _, idxs = nn.kneighbors(s1_matrix)

        other_ids = other_grp["entity_id"].tolist()
        s1_ids = s1_grp["entity_id"].tolist()
        for row_i, neighbor_idxs in enumerate(idxs):
            s1_id = s1_ids[row_i]
            for j in neighbor_idxs:
                cands[s1_id].add(other_ids[j])
    return cands


def generate_candidates(s1_df, s2_df, s3_df, top_k=TOP_K):
    """
    Returns: dict entity_id(S1) -> sorted list of candidate entity_ids
    (S2 and/or S3), union of exact-key blocking and TF-IDF kNN blocking.
    """
    s1p, s2p, s3p = _prep(s1_df), _prep(s2_df), _prep(s3_df)

    exact2 = _exact_key_candidates(s1p, s2p)
    exact3 = _exact_key_candidates(s1p, s3p)
    knn2 = _tfidf_knn_candidates(s1p, s2p, top_k)
    knn3 = _tfidf_knn_candidates(s1p, s3p, top_k)

    result = {}
    for eid in s1p["entity_id"]:
        merged = set()
        merged |= exact2.get(eid, set())
        merged |= exact3.get(eid, set())
        merged |= knn2.get(eid, set())
        merged |= knn3.get(eid, set())
        result[eid] = sorted(merged)
    return result
