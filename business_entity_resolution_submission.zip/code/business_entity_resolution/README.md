# Business Entity Resolution — Pipeline

Matches Source-1 (reference) business records to Source-2 / Source-3 records
across US, India, and (test-only) France, using blocking + a scikit-learn
classifier, optimized for macro F_0.5.

## ⚠️ About the data in this folder
The real challenge dataset (`train_source1.tsv`, `train_source2.tsv`,
`train_source3.tsv`, `train_ground_truth.tsv`, `test_source*.tsv`) was not
provided to build this project — only the problem statement PDF was.
`src/generate_synthetic_data.py` fabricates a structurally-identical dummy
dataset so the whole pipeline is runnable and testable end to end.

**To use with the real dataset:** drop the official files into
`dataset/train/` and `dataset/test/` with the exact same filenames — no
code changes needed, everything below works unchanged.

## Pipeline stages
1. **`normalize.py`** — lowercase, legal-suffix canonicalization
   (Corp/Corporation, Pvt Ltd/Private Limited...), address abbreviation
   normalization (Rd/Road...), tokenization.
2. **`blocking.py`** (candidate generation) — union of:
   - exact-key blocking: `(country, first normalized name token)`
   - character n-gram TF-IDF + cosine k-NN within each country group
     (catches typos, reordering, abbreviations the exact key misses)
   This determines the recall ceiling; it deliberately over-generates.
3. **`features.py`** — 9 pairwise similarity features (name/address
   character similarity, token Jaccard, prefix/token overlap, country
   match). No external string-distance library required.
4. **`train_model.py`** — grouped train/validation split (by S1 entity),
   labels candidate pairs from ground truth, trains a `RandomForestClassifier`
   (scikit-learn, BSD-3 license, far under the 8B-parameter cap), then
   sweeps the decision threshold on the validation split to maximize
   macro-averaged F_0.5 (matching the leaderboard metric exactly).
5. **`predict.py`** — runs blocking + the trained model on the test set,
   writes `output/candidate_pairs.tsv` (the blocking output the model
   scored) and `output/matching_results.tsv` (final matches after
   thresholding).
6. **`validate_submission.py`** — stdlib-only local check of both output
   files against the challenge's format rules (one row per S1 entity, no
   duplicate/self/foreign ids, matches ⊆ candidates, etc.) before you
   spend a leaderboard submission.

## How to run end-to-end

```bash
cd code/business_entity_resolution/src

# 0. (Only needed while using the bundled synthetic demo data.)
#    Skip this step once you've dropped the real dataset into dataset/train and dataset/test.
python3 generate_synthetic_data.py --outdir ../../../dataset --n-entities 400

# 1. Train
python3 train_model.py \
    --data-dir ../../../dataset/train \
    --model-out ../model.joblib

# 2. Predict on test set
python3 predict.py \
    --data-dir ../../../dataset/test \
    --model ../model.joblib \
    --out-dir ../../../output

# 3. Validate format before uploading
python3 validate_submission.py \
    --matching ../../../output/matching_results.tsv \
    --candidate ../../../output/candidate_pairs.tsv \
    --test-dir ../../../dataset/test
```

`output/matching_results.tsv` is what you upload to the leaderboard portal.

## Design notes / why these choices
- **No external lookups.** Everything is derived from the three source
  files only — complies with the "no external DB/API/geocoding" rule.
- **Open-set country handling.** Blocking keys and features treat
  `country` as an arbitrary string; nothing is hard-coded to `{US, India}`,
  so unseen labels (France, at test time) degrade gracefully instead of
  breaking the pipeline.
- **Precision-heavy tuning.** Because F_0.5 weights precision 2× recall,
  the classifier threshold is chosen by directly maximizing macro F_0.5 on
  a held-out validation split rather than a generic 0.5 cutoff — this
  matters a lot for singleton entities, where any false-positive match
  costs the full 1.0 score for that row.
- **Grouped validation split.** The split is by whole Source-1 entity (not
  by pair), avoiding leakage of a given entity's positive/negative pairs
  across train and validation.

## Extending this for a real submission
- Add richer features: TF-IDF cosine as a direct feature (not just for
  blocking), phonetic name codes, address component parsing (PIN/state
  extraction), DBA/trade-name handling.
- Try gradient boosting (e.g. `HistGradientBoostingClassifier`, also
  scikit-learn/BSD) or a small calibrated ensemble.
- Tune `TOP_K` in `blocking.py` and re-check the recall ceiling printed by
  `train_model.py` — if it's below ~0.97, widen blocking before touching
  the classifier at all, since blocking recall caps everything downstream.
- Consider per-country threshold tuning if precision/recall differs a lot
  between US/India/France-like distributions.
